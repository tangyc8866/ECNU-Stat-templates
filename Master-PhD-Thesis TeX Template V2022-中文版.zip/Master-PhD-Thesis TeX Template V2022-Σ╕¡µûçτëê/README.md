# ECNU统计学及相关专业研究生毕业论文TeX模板（2022）使用说明

- 更新时间:2022年12月10日
- For **English version users** see below.  

### 1. 概述

- 本模板基于2020年模板重新改写，分中文模板与英文模板，英文模板根据留学生的要求开发。
- 本模板同时适用于硕士与博士研究生的毕业论文写作。
- 本模板基于ctexbook文档类按封面、frontmatter, mainmatter, backmatter结构进行定制。
- 模板对重要字段进行了统一处理，你只需关注你内容的写作，其他都交给定制的模板自动完成，这些字段都在主文Main.tex中需要提供，包括
    - 姓名(中英文)
    - 学号(中英文)
    - 论文题目(中英文)
    - 分类号
    - 研究生类别(博士/硕士)(中英文)
- 模板采用文献库管理、输出与引用文献，考虑到文献出现在大论文的"参考文献"与"研究生期间发表的论文"中，本模板采用biblatex进行文献管理，后台biber (而不是传统的bibtex!)。
- 致谢: 模板开发参照了Wang Tianshu(XJTU)和Wu Yingnian(Ncepubj University)及袁轶君（ECNU）的TeX模板修改而成，参见[link](https://github.com/YijunYuan/ECNU-Undergraduate-LaTeX)

### 2. 文件结构

- 本模板提倡模块化的论文写作方式。所有tex文件，最终都会汇入到`main.tex`中进行编译。
- `~\frontmatter`: 存放正文前面的源文件，包括
    - `Declaration.tex`: 原创申明
    - `Committee.tex`: 答辩委员会空白表
    - `abstrac_chs.tex`: 中文摘要
    - `abstrac_eng.tex`: 英文文摘要
- `~\mainmatter`：存放正文各章的源文件，样例文件包括
    - `Chapter_1.tex`, 第一章源文件
    - `Chapter_2.tex`, 第二章源文件
    - `Chapter_3.tex`, 第三章源文件
    - `Chapter_4.tex`, 第四章源文件
    - `Chapter_5.tex`, 第五章源文件
- `~\backmatter`: 存放正文之后的文件，主要包括
    - `refs.bib`：为文献数据库文件，其中`keyword=pub`表示论文作者已经发表的论文，`keyword=working` 表示论文作者已经完成但未发表(投出或修改中)的论文
    - `refs.tex`: 为输出文献的简单设置
    - `thanks.tex`: 致谢部分
    - `pubs.tex`: 研究生期间发表或投稿的论文
- `~\figrues`: 存放论文中用的图形(建议保存为png类型)
- `~\logos`: 存在封面设计中用的学校logo, 其他logo备选. 它们都经过矢量处理. 
- `~\bib-tex`: 放在bib文献库在biblatex下使用的测试文件，测试可以用bibtex或biblatex编译，强烈建议在先测试后使用: 测试完没有问题再合并放到论文的refs.bib中. 目录下还有一个biblatex的说明文件，供改变文献输出格式或引用方式时参考. 

### 3. 编译环境与使用建议

- 我们强烈推荐使用TeXstudio进行论文编写。

- 本模板在texlive开发， 支持2019及以上版本。不建议使用CTex套装。

- 因涉及文献索引的生成与引用，本模板原则上需要依次进行以下操作：

```
xelatex main.tex
biber main.bcf
xelatex main.tex
xelatex main.tex
```
若文献库没改动，通常一次xelatex编译就可.

- 由于正文中的文件通常较大，本模板按照chapter进行文件分割并使用include管理，其他文件则用input导入。通过`\begin{ducument}`之前的`\includeonly`命令实现单个章节的编译，章节与编号都会保留，强烈建议使用！

- 本模板中文支持通过ctexbook文档类实现,  在ecnuthesis-cn.cls中对应命令

```
\LoadClass[openany]{ctexbook} 
```
对于macbook用户，texstudio中会出现无法预览中文，这时你需要增加参数`fontset`:

```
\LoadClass[openany, fontset=macnew]{ctexbook} 
```
对于Windows用户此命令会导致错误！

- 正文涉及大量的浮动对象，包括章节、公式、表格、图形、列表、定理，任何引用都必要采用浮动的标签。

### 维护者：

* 汤银才（Yincai Tang）
* 微信号: tangyincai
* 邮箱: tangyc8866@qq.com


---

# ECNU TeX template for graduate theses in Statistics and related majors

- Update: Dec 10, 2022

### 1. Overview

- This template is based on the 2020 TeX template, compatible with Chinese and English version. The English template is developed according to the requirements of international students.
- This template is suitable for both master's and doctoral students dissertation writing.
- This template is based on the `ctexbook` document class customized by cover, frontmatter, mainmatter, backmatter structure.
- The template has a uniform treatment of important fields. You only need to focus on your content writing, with the rest left to the custom template automatically. These fields are required to be provided in the main text `main.tex`, including
    - Name (in English and Chinese)
    - Academic number (in English and Chinese)
    - Thesis title (in English and Chinese)
    - Classification number
    - Graduate Student Category (PhD/MSc) (in Chinese and English)
- The template uses `biblatex` to manage, export and cite the literature. Considering that the literature appears in the "References" and "Papers published during graduate studies" of the large thesis, the template uses biblatex for literature management, with biber in the background (instead of the traditional bibtex!).
- Acknowledgements: The template was developed with reference to the TeX templates of Wang Tianshu (XJTU) and Wu Yingnian (Ncepubj University) and Yuan Yijun (ECNU), see [link](https://github.com/YijunYuan/ECNU-Undergraduate-LaTeX)

### 3. Compilation environment and recommendations for use

- We strongly recommend using `TeXstudio` for thesis writing.

- This template was developed under `Mactex` and theoretically supports texlive 2019. The use of the CTeX suite is NOT recommended.

- As it concerns the generation and citation of the bibliographic index, this template requires, in principle, the following procedures in sequence.

```
xelatex main.tex
biber main.bcf
xelatex main.tex
xelatex main.tex
```
However, if the bibliography has not been changed, it is usually possible to compile using `xelatex` once.

- Since the files in the body are usually large, this template splits the files by chapters and manages them with `include` technology in TeX, while other files are imported with input. Compilation of individual chapters is achieved with the `\includeonly` command before `\begin{ducument}`, with all the numbering are preserved.  This is highly recommended for efficiency!

- The main text involves a large number of floating objects, including chapters, formulas, tables, graphs, lists, theorems. Any references to them are necessary with floating tags.

### Maintainer 

* Yincai Tang (汤银才)
* Wechat: tangyincai
* E-mail: tangyc8866@qq.com

