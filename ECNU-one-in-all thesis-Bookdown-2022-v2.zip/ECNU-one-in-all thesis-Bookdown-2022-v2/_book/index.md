---
title: "学位论文题目学位论文题目学位论文题目"
author: "张小六"
date: "2022-12-12"
site: bookdown::bookdown_site
documentclass: book
# 文档类型:
# 本科: document-bachelor: true
# 专硕: document-premaster: true
# 硕士: document-master: true
# 博士: document-doctor: true
#document-premaster: true
#document-master: true
#document-doctor: true
document-bachelor: true
abstract-zh: "ECNUThesis-bookdwon模板 是根据华东师范大学《本科论文指导手册》和《研究生学位论文及其摘要的撰写和印制要求》而制作的 \\LaTeX\\ 论文模板。"
abstract-en: "This is a English abstract."
baseinfo:
  subtitle: "学位论文副标题"  # 根据需要使用
  etitle: "Title of the Thesis Title of the Thesis Title of the Thesis"
  esubtitle: "Subtitle of the Theisis"
  studentid: "20163160102"
  school: "统计学院"
  major: "统计学"
  class: "0212.1"
  field: "应用统计"
  advisor: "陈大牛"
  position: "教授"
  grade: ""
  graduateyear: "2021"
  schoolcode: "10269"
  score: "4.0"
  date: "2022-12-12"
  keywordzh: ["统计","机器学习"]
  keyworden: ["Statistics", "Machine Learning"]
masterinfo:  # 研究生，设置英文标题, 本科生不需要填写
  eauthor: "Xiaowu Zhang"
  eaffil: "School of Statistics"
  emajor: "Statistics"
  edirection: "Applied Statistics"
  esupervisor: "Daniu Chen  (Professor)"  
bibliography: [refs.bib]
biblio-style: gb7714-2015ay
link-citations: yes
description: "这是华东师范大学的本科、硕士研究生与博士研究生的毕业论文模板. 模板是基于bookdown开发，结果可以生成bookdown的bookdown::gitbook (html)版本及xelatex编译生成的pdf版本. pdf版本基于TeX进行根据学位论文的(文档)类型定制."
---


# 模板特色  {.unnumbered} 

本模模板参考了中国人民大学的毕业论文的bookdwon模板及 @bookdown-Tang 的bookdown中文书稿写作手册, 集成了不同学位(学士/硕士/博士)的论文的要求. 

1. 根据华东师范大学学士/硕士/博士毕业论文的要求定制

1. 相比于Word和 TeX 提升50-80\%的工作效率

1. 通过Rmarkdown包实现对R, markdown,  TeX 的全面支持

1. 通过mathjax支持 TeX 中公式的输入

1. 通过pandoc实现高精度pdf输出

1. 通过章节分类管理实现快速编译与整合

1. 支持直接运行R和Python代码，并将生成的图形和表格嵌入到文档中

1. 支持本地图形的插入

1. 支持生成的R与Python图形自动添加题注(caption)

1. 支持使用浮动对象(标题、公式、图形、表格、文献)的引用

1. 支持R代码抄录，且语法高亮显示

1. 支持Python代码抄录，且语法高亮显示 

1. 除必要的公式外，免去复杂的 TeX 排版命令, 仅通过简单的markdown标记语言实现快速写作


## 软件安装 {-}

1. [R3.6.2以上](https://www.r-project.org/)

2. [Rstudio](https://rstudio.com/) 

3. R包: rmarkdown(支持R+markdown+TeX写作)

4. R包: bookdown (支持pdf, gitbook, epub三类输出) 

5. TeX: TeXLive2019及以上(适用于Windows, MacOS, Linux)

## bookdown使用说明 {-}

见 @bookdown-Tang 及附录 \@ref(bookdown) 详细介绍. 


