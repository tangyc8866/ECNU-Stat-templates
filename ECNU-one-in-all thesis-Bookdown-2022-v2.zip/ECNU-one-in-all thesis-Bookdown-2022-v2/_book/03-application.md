# 一些应用例子 {#examples}

本章给出一些案例，说明本文介绍的方法的可行性.


## 应用一：`Bookdown`中的公式 {#formulas}

第\@ref(formulas) 节的内容讲述浮动对象公式的标签与引用[@xie2015; @bookdown2016].

### 公式标签的设定 {#secA-1-1}

`Rmarkdown`中公式除了无标号的公式(用一对`$$`实现)，可以使用`LaTeX`中的`equation`环境, 尽管无法实现类似的WYSIWYG, 但可设置标签. 标签格式为 `(\#eq:label)`, 其中`eq`是关键字，例如
```
\begin{equation} 
  f\left(k\right) = \binom{n}{k} p^k\left(1-p\right)^{n-k}
  (\#eq:binom)
\end{equation} 
```


显示为
\begin{equation} 
  f\left(k\right) = \binom{n}{k} p^k\left(1-p\right)^{n-k}
  (\#eq:binom)
\end{equation} 
对于多行公式可以采用`align`环境，可对多个公式同时进行设置标签，不需要标签则用`\notag`，例如
```
\begin{align} 
g(X_{n}) &= g(\theta)+g'({\tilde{\theta}})(X_{n}-\theta) \notag \\
\sqrt{n}[g(X_{n})-g(\theta)] &= g'\left({\tilde{\theta}}\right)
  \sqrt{n}[X_{n}-\theta ] (\#eq:align)
\end{align}
```
显示为
\begin{align} 
g(X_{n}) &= g(\theta)+g'({\tilde{\theta}})(X_{n}-\theta) \notag \\
\sqrt{n}[g(X_{n})-g(\theta)] &= g'\left({\tilde{\theta}}\right)
  \sqrt{n}[X_{n}-\theta ] (\#eq:align)
\end{align}

### 公式的引用 {#secA-1-2}

公式的引用采用 `\@ref(eq:label)`, 例如上面的二个公式可引用为：
公式\@ref(eq:binom) 和公式 \@ref(eq:align). 


### 插入^[添加一个解释说明的脚注]很大的数学公式


$$    
\begin{aligned}
\lambda 
&=\left (1+\frac{\left(\frac{\bar{X}-\bar{Y}}{\sqrt{((\frac{1}{n}+\frac{1}{m})\sigma^2)}}\right)^2}{\left(\sqrt{\frac{\sum\limits_{i=1}^n(X_i-\bar{X})^2+\sum\limits_{i=1}^m(Y_i-\bar{Y})^2}{(m+n)\sigma^2}}\right)^2(m+n-2)}\right)^{\frac{n+m}{2}} \\ \notag
&=\left(1+\frac{T^2}{n+m-2}\right)^{\frac{n+m}{2}},
\end{aligned}
$$

其中

$$
\begin{aligned}
\quad T^2 
&=\left(\frac{\frac{\bar{X}-\bar{Y}}{\sqrt{((\frac{1}{n}+\frac{1}{m})\sigma^2)}}}{{\sqrt{\frac{\sum\limits_{i=1}^n(X_i-\bar{X})^2+\sum\limits_{i=1}^m(Y_i-\bar{Y})^2}{(m+n)\sigma^2}}}}\right)^2
\end{aligned}
$$

## 应用二：bookdown中图片 {#figures}
第\@ref(figures)节讲述浮动对象图形的标签与引用[@xie2015; @bookdown2016].


### 由`R`生成两个图形并置示例  {#sec3-2-1}

在`R`的代码块选项中设置`out.width='50%'`, `fig.show='hold'`就可获得二个图形的并置. 

(ref:fig4p2) `iris`数据集`Petal.Length} ~ Species` 的散点图.  右侧的图像中散点类型通过`Species`因子的水平给出，见图例. 直线为数据集拟合线性模型的结果.

\begin{figure}
\includegraphics[width=0.5\linewidth]{03-application_files/figure-latex/fig4-2-1} \includegraphics[width=0.5\linewidth]{03-application_files/figure-latex/fig4-2-2} \caption{(ref:fig4p2)}(\#fig:fig4-2)
\end{figure}

### 由`R`生成两个图形堆叠示例  {#sec3-2-2}

\indent
在`R`的代码块选项中设置`out.width='90%'`, `fig.show='hold'`就可获得二个图形的并置. 

(ref:fig4p3) `iris`数据集`Petal.Length} ~ Species` 的散点图.  下方的图像中散点类型通过`Species`因子的水平给出，见图例. 直线为数据集拟合线性模型的结果.

\begin{figure}
\includegraphics[width=0.9\linewidth]{03-application_files/figure-latex/fig4-3-1} \includegraphics[width=0.9\linewidth]{03-application_files/figure-latex/fig4-3-2} \caption{(ref:fig4p3)}(\#fig:fig4-3)
\end{figure}

### 静态图形示例 {#sec3-2-3}

\indent
在`Bookdwon`中插入本地图形可使用命令(示例为`R`logo)

```r
knitr::include_graphics("figures/ecnu_logo.png")
```

(ref:fig4p4) ECNU logo

\begin{figure}

{\centering \includegraphics[width=0.7\linewidth]{figures/ecnu_logo} 

}

\caption{(ref:fig4p4)}(\#fig:fig4-4)
\end{figure}

### 图形引用 {#sec3-2-4}

\indent
图形引用通过`R`代码块的标签引用, 并带前缀`fig:`, 例如

```
图\@ref(fig:fig4-2)和图\@ref(fig:fig4-3)为两个图的并置与堆叠. 
```
输出为: 

图\@ref(fig:fig4-2)和图\@ref(fig:fig4-3)为两个图的并置与堆叠. 



## 应用三: bookdown中的表格 {#tables}

第\@ref(tables)节讲述浮动对象图形的标签与引用[@xie2015; @bookdown2016].

### 表格示例1：由数据生成表格 {#secA-3-1}


```r
knitr::kable(
  head(mtcars[, 1:5], 10), booktabs = TRUE,
  caption = 'mtcars数据的前5行.'
)
```

\begin{table}

\caption{(\#tab:tab3-1)mtcars数据的前5行.}
\centering
\begin{tabular}[t]{lrrrrr}
\toprule
  & mpg & cyl & disp & hp & drat\\
\midrule
Mazda RX4 & 21.0 & 6 & 160.0 & 110 & 3.90\\
Mazda RX4 Wag & 21.0 & 6 & 160.0 & 110 & 3.90\\
Datsun 710 & 22.8 & 4 & 108.0 & 93 & 3.85\\
Hornet 4 Drive & 21.4 & 6 & 258.0 & 110 & 3.08\\
Hornet Sportabout & 18.7 & 8 & 360.0 & 175 & 3.15\\
\addlinespace
Valiant & 18.1 & 6 & 225.0 & 105 & 2.76\\
Duster 360 & 14.3 & 8 & 360.0 & 245 & 3.21\\
Merc 240D & 24.4 & 4 & 146.7 & 62 & 3.69\\
Merc 230 & 22.8 & 4 & 140.8 & 95 & 3.92\\
Merc 280 & 19.2 & 6 & 167.6 & 123 & 3.92\\
\bottomrule
\end{tabular}
\end{table}

### 表格示例2: 由数据框构造表格 {#secA-3-2}

(ref:tab3p2) 遗传连接模型例子中观测到的频数 $y_i$ 和频率 $p(y_i|\pi)$，$i=1, \dots ,4$，197个动物.

\begin{table}

\caption{(\#tab:tab3-2)(ref:tab3p2)}
\centering
\begin{tabular}[t]{lllll}
\toprule
Category & 1 & 2 & 3 & 4\\
\midrule
Frequency $y_i$ & 125 & 18 & 20 & 34\\
Probability $p(y_i\mid\pi)$ & $\frac{1}{2}+\frac{\pi}{4}$ & $\frac{1}{4}(1-\pi)$ & $\frac{1}{4}(1-\pi)$ & $\frac{1}{4}$\\
\bottomrule
\end{tabular}
\end{table}

### 表格引用 {#secA-3-3}

表格引用由代码块的标签(设为`label`)引用实现, 并带前缀`tab:`, 由`\@ref(tab:label)`实现. 例如

```
本章共出现二张表格，即表\@ref(tab:tab3-1)和表\@ref(tab:tab3-2).
```

输出为：

本章共出现二张表格，即表\@ref(tab:tab3-1)和表\@ref(tab:tab3-2).

**注**: 表格中的caption(题图)由文本引用生成.


