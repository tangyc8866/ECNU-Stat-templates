# 研究方法 {#methods}

本章介绍全文用到的一些方法. 

插入一个pdf文件（图片文件），使得其宽度为页面左右边距：


```r
knitr::include_graphics('figures/ecnu_logo.png')
```

\begin{figure}
\includegraphics[width=1\linewidth]{figures/ecnu_logo} \caption{校徽}(\#fig:unnamed-chunk-1)
\end{figure}


