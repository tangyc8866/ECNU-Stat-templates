# 文献综述 {#literature}

介绍论文所用的方法.

这个示例我们使用了**bookdown**包[@R-bookdown]，它是建立在R Markdown和**knitr**[@xie2015]基础上的。

 
