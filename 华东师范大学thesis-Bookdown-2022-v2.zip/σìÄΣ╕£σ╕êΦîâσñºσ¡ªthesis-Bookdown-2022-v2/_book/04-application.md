# 一些应用例子 {#examples}

本章给出一些案例，说明本文介绍的方法的可行性.


## 应用一：bookdown中图片并列

### 由`R`生成两个图形并置示例

在`R`的代码块选项中设置`out.width='50%'`, `fig.show='hold'`就可获得二个图形的并置. 

(ref:sbs) `iris`数据集`Petal.Length} ~ Species` 的散点图.  右侧的图像中散点类型通过`Species`因子的水平给出，见图例. 直线为数据集拟合线性模型的结果.

\begin{figure}
\includegraphics[width=0.5\linewidth]{04-application_files/figure-latex/fig-sbs-1} \includegraphics[width=0.5\linewidth]{04-application_files/figure-latex/fig-sbs-2} \caption{(ref:sbs)}(\#fig:fig-sbs)
\end{figure}


通过代码块的标签就可引用: 图\@ref(fig:fig-sbs)为两个图的并置.

## 应用二：数学环境

插入^[添加一个解释说明的脚注]数学公式：


$$    
\begin{aligned}
\lambda 
&=\left (1+\frac{\left(\frac{\bar{X}-\bar{Y}}{\sqrt{((\frac{1}{n}+\frac{1}{m})\sigma^2)}}\right)^2}{\left(\sqrt{\frac{\sum\limits_{i=1}^n(X_i-\bar{X})^2+\sum\limits_{i=1}^m(Y_i-\bar{Y})^2}{(m+n)\sigma^2}}\right)^2(m+n-2)}\right)^{\frac{n+m}{2}} \\ \notag
&=\left(1+\frac{T^2}{n+m-2}\right)^{\frac{n+m}{2}},
\end{aligned}
$$

其中

$$
\begin{aligned}
\quad T^2 
&=\left(\frac{\frac{\bar{X}-\bar{Y}}{\sqrt{((\frac{1}{n}+\frac{1}{m})\sigma^2)}}}{{\sqrt{\frac{\sum\limits_{i=1}^n(X_i-\bar{X})^2+\sum\limits_{i=1}^m(Y_i-\bar{Y})^2}{(m+n)\sigma^2}}}}\right)^2
\end{aligned}
$$
