\cleardoublepage 

# (APPENDIX) 附录 {-}

# Bookdown中的章节、标题与文献使用说明 {#bookdown}

每一个Rmd文件只包含一章内容，每一章由一个一级标题`#`来指定。


## `Bookdown`中的文献排版 {#bibs}

附录\@ref(bibs)讲解文献库的建立、文献格式与排版方法. [@xie2015; @R-base]

### 文献库建立样例 {#secA-4-1}

根据文献的类型，文献库的格式有14种类型，它们由`title`,`author`, `journal`,`address`等域构成. 最为常见的文献类型是论文(`article`)和图书(`book`), 它们的格式如下
```
    @article{CitekeyArticle,
      author   = "P. J. Cohen",
      title    = "The independence of the continuum hypothesis",
      journal  = "Proceedings of the National Academy of Sciences",
      year     = 1963,
      volume   = "50",
      number   = "6",
      pages    = "1143--1148",
    }
```

```
    @book{CitekeyBook,
      author    = "Leonard Susskind and George Hrabovsky",
      title     = "Classical mechanics: the theoretical minimum",
      publisher = "Penguin Random House",
      address   = "New York, NY",
      year      = 2014
    }
```
其余类型参见网页:[The 14 BibTeX entry types](https://www.bibtex.com/e/entry-types/)。 
文献库通过`BiBTeX`或`BiBer`的运行生成文献目录(bibliography).


### 文献风格  {#secA-4-2}

不同的期刊、书集对文献目录中参考文献的呈现方式有不同的要求，`BiBTeX`是通过风格(style)文件来控制(配合宏包`natbib`使用), `BiBer`是通过选项来控制(配合`biblatex`使用). 

文献呈现的风格分为作者-日期格式(author-date style)和数字格式(numeric)。作者-日期格式共有141个式样，其中最为常用的式样有2个，即`alpha`和`apalike`。 数据格式共88个式样，其中有8类是标准式样，也是最常用的式样，即`abbrv`, `acm`,`ieeetr`,`plain`,`siam`, 和`unsrt`。这些式样的具体形式与介绍见[](https://www.bibtex.com/styles/)

中文的文献排版根据国标GB/T77114-2015的规范，对文献的类型要求提供文献的标识代码，共有18个，例如图书用`M`标识，期刊论文用`J`标识。


## Bookdow中的章节标题 {#sections} 

我们在第\@ref(sections)章讲述章节标题的设置、标签与引用. [@xie2015; @bookdown2016]

### 章节标题 {#secA-5-1}

章节标题用遵从`markdown`的规则，用`#`设置，

- 一级标题用一个 `#`, 在bookdown中表示`章`, 相当于 TeX 中的`\chapter{}`

- 二级标题用二个 `#`, 在bookdown中表示`节`, 相当于 TeX 中的`\section{}`

- 三级标题用三个 `#`, 在bookdown中表示`子节`, 相当于 TeX 中的`\subsection{}`

还可以有更深的标题.

### 章节标题标签的设定与引用 {#secA-5-2}

章节标题标签可在标题后用 `{#label}`来设定，引用方式为`\@ref(label)`. 例如


```r
第\@ref(sections)章\@ref(secA-5-2)节讨论标题标签的设定与引用.
```

显示为：

第\@ref(sections)章\@ref(secA-5-2)节讨论标题标签的设定与引用.


## 列表 {#list}

### 嵌套的有序列表 {#secA-6-1}

1. 项目列表

1. 项目列表

1. 项目列表

    a. 项目列表

    a. 项目列表

    a. 项目列表
    
### 嵌套的无序列表 {#secA-6-2}

- 项目列表

- 项目列表

    - 项目列表

    - 项目列表

    - 项目列表
   
关于Bookdown中文书稿的写作参见 @bookdown-Tang. 
