# 研究方法 {#methods}

本章介绍全文用到的一些方法. 


## 定理标签的设定 {#sec4-2}

\indent
这里我们先叙述几个定义和定理，并给出几个例子.

::: {.lemma #lem4-1}
带标签的引理.
:::

::: {.theorem #thm4-1 name="无限群"}
带标签与名字的定理.
:::

::: {.proof}
这里是定理的证明部分.
:::

::: {.definition #def4-1}
带标签的定义.
:::


::: {.example #exm4-1}
带标签的例子.
:::


## 定理的引用 {#sec4-3}

\indent
例\@ref(exm:exm4-1), 定义\@ref(def:def4-1) 定理\@ref(thm:thm4-1)为定理类引用.



