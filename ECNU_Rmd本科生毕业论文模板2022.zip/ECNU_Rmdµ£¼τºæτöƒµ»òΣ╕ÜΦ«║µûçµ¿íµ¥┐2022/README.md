# ECNU-本科毕业论文Rmarkdown模板

更新时间:2022年3月31日

### 1. 概述

本模板基于ECNU-本科毕业论文TeX模板进行定制, 突出文学化统计编程给论文写作带来的便利. TeX模板参照了袁轶君（Yijun Yuan）的TeX模板修改而成，参见[link](https://github.com/YijunYuan/ECNU-Undergraduate-LaTeX)

参考文献采用biblatex进行管理，后台biber (而不是传统的bibtex!), 文献库采用满足国家标准GB/T7714-2015的[胡振震-biblatex样式包](https://github.com/hushidong/biblatex-gb7714-2015)，参见[hushidong](https://github.com/hushidong)详细介绍。

本模板基于book文档类构建，有许多个小文件组成。本模板提倡模块化的论文写作方式。所有rmd和TeX文件，最终都会汇入到`main.tex`中进行编译。

本模板在R4.0.1及texlive 2020上开发，并需要knitr, rmarkdown等包的支持， 它们在启动main.rmd时会自动加载。

### 2. 各文件作用

#### `main.rmd`

本模板的核心，控制着整个项目的结构。在这个文件中，你需要修改的只有文章正文的各个章节所在的rmd文件，它们被建议放置在`~/body/`中。

#### `~\setup\ctex_header.tex`, `~\setup\ctex_format.tex` 

它们分别为用于定制本模板需要的TeX包和相应的页面与环境设置。简而言之，请不要轻易修改或删除本文件中的任何内容，特别是不要修改宏包的加载顺序，除非你真的知道你在做什么。这真的非常重要！！！！！！！

#### `~\preface\paper_info.tex`

本文件中定义了各种论文的基本信息，如作者名称，完成日期，中英文关键词等，需要你自己填写修改。

#### `~\bibtest\biber-test.tex`

这是一个biblatex的测试文件，涉及的`reference`目录中的二个bib文件. 建议使用本模板时先熟悉bib文献库的编写文件，并作测试。

#### `~\preface\inner-cover.tex`

这个文件定义了论文的封面，请勿进行任何修改，除非你真的知道你在做什么。

#### `~\preface\abstract-CHS.tex, ~\preface\abstract-ENG.tex`

这个两个文件定义了中英文的摘要（事实上还有关键词，只是关键词已经在`paper_info.tex`中填写所以在这个文件中会自动调用，你就不用管了）。


#### `~\body\ch1-xxx.rmd`...,`~\body\ch4-xxx.rmd`

这些文件定义了正文部分。这里我们按照chapter进行文件分割并在`main.rmd`作为子文档由`child`选项管理。

这些文件包括了各种常用的格式，包括公式、表格、图形、列表、定理及各类引用等。

#### `~\body\appendix-A.rmd`

这个文件给出了论文可能用到的附录，包括R和Python代码的排版。

#### `~\body\thanks.rmd`

这个文件为作者要致谢的内容，请自行修改填写。

#### `~\figures\`

此文件夹存放本地图片, 包括ECNU logo。

#### `~\reference\thesis-ref.bib`
#### `~\reference\refs.bib`

存放了所有的参考文献条目。本模板使用的biblatex系统可以处理多bib文件，我们建议你把所有条目都放在refs.bib文件中, 它列举了许多不同类型的文献类型。biber支持导入多个文献库。

### 3. 使用方法与编译环境

本文档需要在Rstudio中进行编写，并由knitr生成TeX, 再由xelatex编译生成pdf文件。第一次编译需要较长时间，编译过程中会生成标准的TeX文件，若编译过程中出现TeX的文件可自行按下面的方式编译，编译环境建议用TeXStudio。


```
xelatex main
bibtex main
xelatex main
xelatex main
```

### 4. 其他

相信使用这份模板的人并不都精通TeX系统，甚至连作者自己也算不上精通，所以有些问题也需要慢慢摸索修改。

### 维护者：

* 汤银才（Yincai Tang）
* 微信号: tangyincai



